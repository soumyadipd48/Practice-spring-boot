package com.tweetapp;

import java.util.Collections;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;




@SpringBootApplication
public class TweetappApplication {

	public static void main(String[] args) {
		SpringApplication.run(TweetappApplication.class, args);
	}
	
	
	@Bean
	  public OpenAPI springShopOpenAPI() {
	      return new OpenAPI()
	              .info(new Info().title("Tweet APP Api")
	              .description("An application where user can post, like and comment on a tweet, at the same time search other users and their tweets.")
	              .version("v1.0")
	              .license(new License().name("SD License").url("http://springdoc.org")))
	              .externalDocs(new ExternalDocumentation()
	              .description("Contact : Soumyadip De")
	              .url("https://github.com"));
	  }

}
