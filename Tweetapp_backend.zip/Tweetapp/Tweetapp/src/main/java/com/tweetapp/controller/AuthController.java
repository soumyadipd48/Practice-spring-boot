package com.tweetapp.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.dto.AuthenticationRequest;
import com.tweetapp.dto.AuthenticationResponse;
import com.tweetapp.model.UserModel;
import com.tweetapp.exception.UsernameAlreadyExists;
import com.tweetapp.repository.UserRepository;
import com.tweetapp.service.KafkaSender;
import com.tweetapp.service.UserModelService;

import ch.qos.logback.classic.BasicConfigurator;

//import io.swagger.annotations.Api;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
//@Api
public class AuthController {
	
	private static final Logger logger = Logger.getLogger(AuthController.class);
	
	
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserModelService userModelService;

	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	KafkaSender kafkaSender;

	@PostMapping("/tweets/register")
	public ResponseEntity<?> subscribeClient(@RequestBody UserModel userModel) {
		
		String MessageSuccess = "User Registering";
		String MessageError = "User not Registered Error";

		try {
			UserModel savedUser = userModelService.createUser(userModel);
			logger.info("New user registering");
			kafkaSender.send(MessageSuccess);
			return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
		} catch (UsernameAlreadyExists e) {
			logger.error("User not registered-email already taken");
			kafkaSender.send(MessageError);
			return new ResponseEntity<>(new AuthenticationResponse("Given userId/email already exists"),
					HttpStatus.CONFLICT);
		} catch (Exception e) {
			logger.error("User not registered-internal error");
			kafkaSender.send(MessageError);
			return new ResponseEntity<>(new AuthenticationResponse("Application has faced an issue"),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		

	}

	@PostMapping("/tweets/login")
	public ResponseEntity<?> authenticateClient(@RequestBody AuthenticationRequest authenticationRequest) {
		String username = authenticationRequest.getUsername();
		String password = authenticationRequest.getPassword();
		String MessageSuccess = "User logged-In-new message";
		String MessageError = "User not logged-In error";
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (Exception e) {
			logger.error("User not logged-In error");
			kafkaSender.send(MessageError);
			return new ResponseEntity<>(new AuthenticationResponse("Bad Credentials " + username),
					HttpStatus.UNAUTHORIZED);
		}
		logger.info("User logged-In");
//		logger.warn("User logged-In warn");
//		logger.error("User logged-In error");
//		logger.fatal("User logged-In fatal");
//		logger.trace("User logged-In trace");
		kafkaSender.send(MessageSuccess);
//		
//		logger.debug("exit");
		return new ResponseEntity<>(userModelService.findByUsername(username), HttpStatus.OK);
	}
}
